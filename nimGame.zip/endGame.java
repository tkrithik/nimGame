import java.util.Scanner;

class endGame{
  public static void main (String[] args) {
    System.out.println("endGame instantiated.");
  }

  public endGame() {
    playerName nameClass = new playerName();
    mathClass mathClass = new mathClass();
    
    System.out.println("The Game Of Nim Has Ended!");
    
    System.out.println(nameClass.getName(1) + "'s Score: " + Integer.toString(mathClass.getScore(1) + mathClass.getExtraPoint(1)));
    
    System.out.println(nameClass.getName(2) + "'s Score: " + Integer.toString(mathClass.getScore(2) + mathClass.getExtraPoint(2)));
    
    if (mathClass.getScore(1) + mathClass.getExtraPoint(1) < mathClass.getScore(2)) {
      
      System.out.println(nameClass.getName(2) + " is the winner!");
      
    } else if (mathClass.getScore(2) + mathClass.getExtraPoint(2) < mathClass.getScore(1)) {
      
      System.out.println(nameClass.getName(1) + " is the winner!");
      
    } else {
      
      System.out.println("The Game is Tied!");
      
    }

    Scanner input = new Scanner(System.in);
    System.out.println("Would you like to replay? Please respond with y/n");
    String question = input.nextLine();

    replayGame(question);
  }

  private static void replayGame(String question) {
    Scanner input = new Scanner(System.in);
    if (question.charAt(0) == 'y') {
      nimRunner runnerClass = new nimRunner();
    } else if (question.charAt(0) != 'y' && question.charAt(0) != 'n') {
      System.out.println("Please respond with y/n");
      String answer = input.nextLine();
      replayGame(answer);
    }
  }
}