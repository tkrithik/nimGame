import java.util.Scanner;

class playerName{

  private static String playerOneName;
  private static String playerTwoName;
  
  public static void main (String[] args) {
    System.out.println("playerName instantiated.");
  }

  public playerName() {
    //System.out.println("playerName instantiated.");
  }

  public static void askName() {
    Scanner input = new Scanner(System.in);          
    System.out.println("Enter Player One's Name:");

    playerOneName = input.nextLine();  
    System.out.println("Welcome " + playerOneName);  

    System.out.println("Enter Player Two's Name:");
    playerTwoName = input.nextLine();
    System.out.println("Welcome " + playerTwoName);
  }

  public static String getName(int playerNum) {
    if (playerNum == 1) {
      return playerOneName;
    } else {
      return playerTwoName;
    }
  }

}