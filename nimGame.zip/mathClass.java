import java.lang.Math;
import java.util.Scanner;

class mathClass{

  private static int playerOneScore = 0;
  private static int playerTwoScore = 0;

  private static int playerOneExtraPoint = 0;
  private static int playerTwoExtraPoint = 0;

  private static int randomChosenNum;
  
  public static void main (String[] args) {
    System.out.println("mathClass instantiated.");
  }

  public mathClass() {
    randomNum();
  }

  public static void randomNum() {
    randomChosenNum = (int) (Math.random() * 50);
    if (randomChosenNum < 10) {
      randomChosenNum = (int) (Math.random() * 50);
    }
  }

  public static int getRandomNum() {
    return randomChosenNum;
  }

  public static int getScore(int playerNum) {
    if (playerNum == 1) {
      return playerOneScore;
    } else {
      return playerTwoScore;
    }
  }

  public static int getExtraPoint(int playerNum) {
    if (playerNum == 1) {
      return playerOneExtraPoint;
    } else {
      return playerTwoExtraPoint;
    }
  }

  public static void guessNum(int playerNum) {
    Scanner input = new Scanner(System.in);
    playerName nameClass = new playerName();
    System.out.println(nameClass.getName(playerNum) + " guess the number of pieces for 5 extra points: ");
    int guess = Integer.parseInt(input.nextLine());
    if (guess == randomChosenNum) {
      if (playerNum == 1) {
      playerOneExtraPoint += 5;
    } else {
      playerTwoExtraPoint += 5;
    }
    }
  }

  public static void pick(int playerNum) {

    if ((randomChosenNum) == 0) {

      endGame endClass = new endGame();
    }
    else {
      playerName nameClass = new playerName();
    Scanner input = new Scanner(System.in);          
    System.out.println(nameClass.getName(playerNum) + " Enter Your Pick:  (Number of Pieces Left: " + Integer.toString(randomChosenNum) + ")");

    int pickNum = Integer.parseInt(input.nextLine());
    
    if (((pickNum > (int) (randomChosenNum/2)) && (randomChosenNum != 0)) && ((pickNum != 1) && (randomChosenNum != 0)) || (pickNum == 0 )) {
      System.out.println("Please pick an amount greater than 0 and less than " + Integer.toString(((int) (randomChosenNum/2) +1)));
        pick(playerNum);
    }
    
    else {
      
      if (playerNum == 1) {
        playerOneScore += pickNum;
        System.out.println("Player " + Integer.toString(playerNum) + " Score: " + Integer.toString(playerOneScore));
        System.out.println("Player " + Integer.toString(playerNum + 1) + " Score: " + Integer.toString(playerTwoScore));
        randomChosenNum = randomChosenNum - pickNum;
        //System.out.println(randomChosenNum);
        pick(2);
      } else {
        playerTwoScore += pickNum;
        System.out.println("Player " + Integer.toString(playerNum-1) + " Score: " + Integer.toString(playerOneScore));
        System.out.println("Player " + Integer.toString(playerNum) + " Score: " + Integer.toString(playerTwoScore));
        randomChosenNum = randomChosenNum - pickNum;
        //System.out.println(randomChosenNum);
        pick(1);
      }
    }
    }
  }

}