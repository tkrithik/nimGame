import java.lang.Math;

class nimRunner {
  public static void main(String[] args) {
    //System.out.println("nimRunner started");

    playerName nameClass = new playerName();
    mathClass mathClass = new mathClass();

    nameClass.askName();

    mathClass.guessNum(1);
    mathClass.guessNum(2);
    

    mathClass.pick((int) (Math.random()*2) + 1);
  }

  public nimRunner() {
    playerName nameClass = new playerName();
    mathClass mathClass = new mathClass();

    nameClass.askName();

    mathClass.guessNum(1);
    mathClass.guessNum(2);
    

    mathClass.pick((int) (Math.random()*2) + 1);
  }
}